#/bin/sh
cc -o sspoof sspoof.c
echo "Compilation OK"
echo "Lance ./scan.sh"
echo "Bye"
